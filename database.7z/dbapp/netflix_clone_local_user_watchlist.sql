-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: netflix_clone_local
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_watchlist`
--

DROP TABLE IF EXISTS `user_watchlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_watchlist` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `movie_id` bigint DEFAULT NULL,
  `tv_series_id` bigint DEFAULT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9fhbuf2rh3u2d0citgjx86id9` (`movie_id`),
  KEY `FKd8lethh8i4eu5bjfpxv5lkmcb` (`tv_series_id`),
  KEY `FKkqtrlvna3jr37u11m0dgcdp8b` (`user_id`),
  CONSTRAINT `FK9fhbuf2rh3u2d0citgjx86id9` FOREIGN KEY (`movie_id`) REFERENCES `movies` (`id`),
  CONSTRAINT `FKd8lethh8i4eu5bjfpxv5lkmcb` FOREIGN KEY (`tv_series_id`) REFERENCES `tv_series` (`id`),
  CONSTRAINT `FKkqtrlvna3jr37u11m0dgcdp8b` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9568 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_watchlist`
--

LOCK TABLES `user_watchlist` WRITE;
/*!40000 ALTER TABLE `user_watchlist` DISABLE KEYS */;
INSERT INTO `user_watchlist` VALUES (3,822119,NULL,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(9549,122,NULL,'0a856007-119b-4ff4-bfb3-6397e4107cd8'),(9552,NULL,226637,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(9553,NULL,233742,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(9555,NULL,259288,'0a856007-119b-4ff4-bfb3-6397e4107cd8'),(9556,767,NULL,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(9557,122,NULL,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(9558,672,NULL,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(9559,120,NULL,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(9560,1234821,NULL,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(9561,762509,NULL,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(9563,NULL,259288,'51bc6695-23fd-4311-bbf3-41eb7a090a52'),(9564,1084199,NULL,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(9565,NULL,108978,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(9566,NULL,259288,'3010b75d-a91e-49a4-b3ee-9e762070d9a8');
/*!40000 ALTER TABLE `user_watchlist` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-16  7:58:26
