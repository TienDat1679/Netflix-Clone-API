-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: netflix_clone_local
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_info`
--

DROP TABLE IF EXISTS `user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_info` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `enabled` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `otp` int DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `roles` varbinary(255) DEFAULT NULL,
  `forgotpassword_fpid` int DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `end_date` datetime(6) DEFAULT NULL,
  `start_date` datetime(6) DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKgnu0k8vv6ptioedbxbfsnan9g` (`email`),
  UNIQUE KEY `UKb0x5phcx5j0ol7s0akvgu2g4b` (`forgotpassword_fpid`),
  CONSTRAINT `FK9ktw43wcrtu1ey5bqrud5j5g` FOREIGN KEY (`forgotpassword_fpid`) REFERENCES `forgot_password` (`fpid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_info`
--

LOCK TABLES `user_info` WRITE;
/*!40000 ALTER TABLE `user_info` DISABLE KEYS */;
INSERT INTO `user_info` VALUES ('0a856007-119b-4ff4-bfb3-6397e4107cd8','nhi@gmail.com',1,'nhi',483811,'$2a$10$sg.PZXdLykUiKMv7LhgcH.AxNyfgN7K1tbtj.zqNDB3KoR.hIeL6S',NULL,NULL,'2004-05-06',NULL,NULL,'avatar_2'),('3010b75d-a91e-49a4-b3ee-9e762070d9a8','hao2004@gmail.com',1,'hao222',NULL,'$2a$10$3SzvcZoQd92vs4puu6LFNu7QJOHKw4w9TKj2ZL7xZG6HZNfTgqERq',NULL,NULL,NULL,NULL,NULL,'avatar_3'),('51bc6695-23fd-4311-bbf3-41eb7a090a52','vophuhao20022004@gmail.com',1,'phuhao',NULL,'$2a$10$F8NBHuOSIEgUj22UKkT0Mul5KKdoIheOAZoR8oo3vyZ/xrYQYHugC',NULL,NULL,NULL,'2025-06-15 14:03:47.292715','2025-05-15 14:03:47.292715','avatar_4'),('ad879521-4fa7-4fe2-87d8-0b87c961bfc9','vophuhao2004@gmail.com',1,'Tien Dat ne',NULL,'$2a$10$2RmRpeGJXjko8BI8iU0cHOusfcpLNieY0wafeIQHaJOlmB2GKgwE6',NULL,NULL,'2025-08-30','2025-09-13 14:44:31.634758','2025-05-13 14:44:31.634758','avatar_arcane_1'),('c0f24daa-664c-4587-916e-8a2234950a31','vophuhao@gmail.com',1,'phuhao2004',NULL,'$2a$10$jrMoAq87eztH/IgGfJ.1seBSrPDef9A8Ci77nnotb3WcjBECWoHUy',NULL,NULL,NULL,'2025-06-15 14:39:49.235369','2025-05-15 14:39:49.235369','avatar_4'),('e19957fd-e1fd-4336-98d6-9fd5dece9943','admin@gmail.com',1,'admin',NULL,'$2a$10$USz69Lc5RWB0ms6RLyR8te29rbTzZbGShM5XKIabh9y9EA4QwVo/m',_binary '�\�\0sr\0java.util.ArrayListx�\��\�a�\0I\0sizexp\0\0\0w\0\0\0t\0ADMINx',NULL,NULL,NULL,NULL,'avatar_4'),('f8aa324f-76ed-465f-8f39-cd9d07cbb22d','hao@gmail.com',1,'Hao Milk',NULL,'$2a$10$n.DhsIWb0gzUIVqIlNFlLeLnan0xfUfvMXC92rw7no4DZWzgyeorm',NULL,NULL,'2008-05-20',NULL,NULL,'avatar_1');
/*!40000 ALTER TABLE `user_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-16  7:58:26
