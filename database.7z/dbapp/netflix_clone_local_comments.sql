-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: netflix_clone_local
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `likes` bigint DEFAULT NULL,
  `media_id` bigint DEFAULT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKk2lq67pxpkj1krbvluxccwd9m` (`user_id`),
  CONSTRAINT `FKk2lq67pxpkj1krbvluxccwd9m` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,'phim hayyyy','2025-05-06 11:28:20.882963',4,259288,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(2,'phim khoong hayyyy','2025-05-06 11:30:42.952862',8,259288,'0a856007-119b-4ff4-bfb3-6397e4107cd8'),(3,'oh no','2025-05-08 17:51:44.714638',0,259288,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(4,'doi y roi. Phim chan','2025-05-08 18:08:46.561765',1,259288,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(5,'hahaha','2025-05-08 18:09:58.405177',0,259288,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(6,'alo','2025-05-09 10:46:38.397076',0,259288,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(7,'nooooooo','2025-05-09 10:47:47.968603',0,259288,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(8,'oh noo','2025-05-09 10:50:53.877949',0,259288,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(9,'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa','2025-05-09 10:51:29.444665',0,259288,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(10,'???','2025-05-09 10:58:06.327894',1,259288,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(11,'hay nha bro','2025-05-09 11:06:26.129360',0,767,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(12,'kho nha bro','2025-05-09 11:07:44.729190',1,767,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(13,'ahihi','2025-05-09 11:21:29.832709',0,259288,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(14,'phim te','2025-05-09 11:28:47.280677',0,1272149,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(15,'chan chua','2025-05-13 10:02:39.048950',1,226637,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(16,'sadasd','2025-05-13 13:03:47.941162',0,259288,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(17,'ddaxsas','2025-05-14 21:10:12.375947',0,259288,'0a856007-119b-4ff4-bfb3-6397e4107cd8'),(18,'???????????','2025-05-14 22:51:36.004903',0,259288,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(19,'kjhjkhkj','2025-05-15 02:20:56.137250',0,259288,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(20,'hehehee','2025-05-15 03:06:34.222182',0,259288,'f8aa324f-76ed-465f-8f39-cd9d07cbb22d'),(21,'dau','2025-05-15 03:19:02.638928',1,1126166,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(22,'phim hay','2025-05-15 13:59:25.892101',1,762509,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(23,'phim hay nha bro','2025-05-15 14:05:09.070706',0,259288,'51bc6695-23fd-4311-bbf3-41eb7a090a52'),(24,'phim hay','2025-05-15 14:31:54.766626',1,1084199,'ad879521-4fa7-4fe2-87d8-0b87c961bfc9');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-16  7:58:27
