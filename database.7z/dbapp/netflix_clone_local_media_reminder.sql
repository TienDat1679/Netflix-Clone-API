-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: netflix_clone_local
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `media_reminder`
--

DROP TABLE IF EXISTS `media_reminder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_reminder` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `media_id` bigint DEFAULT NULL,
  `notified` bit(1) NOT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1hovd44kqgd3dlec8vp00ko13` (`user_id`),
  CONSTRAINT `FK1hovd44kqgd3dlec8vp00ko13` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_reminder`
--

LOCK TABLES `media_reminder` WRITE;
/*!40000 ALTER TABLE `media_reminder` DISABLE KEYS */;
INSERT INTO `media_reminder` VALUES (12,'2025-05-13 11:49:00.271701',216082,_binary '\0','0a856007-119b-4ff4-bfb3-6397e4107cd8'),(13,'2025-05-13 11:54:21.652236',402431,_binary '','0a856007-119b-4ff4-bfb3-6397e4107cd8'),(15,'2025-05-15 03:07:06.789940',912649,_binary '','f8aa324f-76ed-465f-8f39-cd9d07cbb22d'),(16,'2025-05-15 13:46:04.080344',950396,_binary '\0','ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(18,'2025-05-15 13:58:02.921537',912649,_binary '','ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(20,'2025-05-15 22:08:37.245153',950396,_binary '\0','3010b75d-a91e-49a4-b3ee-9e762070d9a8'),(21,'2025-05-15 22:08:38.992179',216082,_binary '\0','3010b75d-a91e-49a4-b3ee-9e762070d9a8'),(22,'2025-05-16 07:39:10.024425',549509,_binary '\0','ad879521-4fa7-4fe2-87d8-0b87c961bfc9'),(35,'2025-05-16 07:55:52.685365',533535,_binary '\0','f8aa324f-76ed-465f-8f39-cd9d07cbb22d');
/*!40000 ALTER TABLE `media_reminder` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-16  7:58:25
